from pathlib import Path
import re,json,argparse,subprocess
parser=argparse.ArgumentParser(description="Extract legacy process setup and research-node metadata from the pinned Civ13 source checkout without running game code.")
parser.add_argument("--source", type=Path, required=True, help="Civ13 repository checkout at the documented commit")
parser.add_argument("--output", type=Path, default=Path(__file__).parent, help="Output directory; defaults to this script directory")
options=parser.parse_args()
S=options.source; O=options.output
O.mkdir(parents=True,exist_ok=True)
SHA='5bf351248de6050876fe5b53f91209a970cc5668'
actual=subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD'],text=True).strip()
if actual != SHA:
 raise SystemExit('Expected pinned commit '+SHA+', found '+actual)
BASE=f'https://github.com/Civ13/Civ13/blob/{SHA}/'
def link(p,a,b=None):return f'[{p}:{a}'+(f'-{b}' if b else '')+f']({BASE}{p}#L{a}'+(f'-L{b}' if b else '')+')'
incs=[]
for n,l in enumerate((S/'civ13.dme').read_text().splitlines(),1):
 m=re.match(r'^#include "(.+)"',l)
 if m:incs.append((m[1].replace('\\','/'),n))
rows=[]
for p,n in incs:
 if not p.startswith('code/processes/') or p.split('/')[-1].startswith('_'):continue
 text=(S/p).read_text(errors='replace')
 for m in re.finditer(r'^(/process/[^\s(]+?)/setup\(\)(.*?)(?=^/|\Z)',text,re.M|re.S):
  body=m[2]; row={'type':m[1],'file':p,'line':text[:m.start()].count('\n')+1,'dme_line':n}
  for prop in ['name','schedule_interval','start_delay','fires_at_gamestates','priority']:
   v=re.search(r'^\s*'+prop+r'\s*=\s*(.*)',body,re.M)
   row[prop]=v[1].split('//')[0].strip() if v else '(inherited)'
  rows.append(row)
(O/'process_catalog.json').write_text(json.dumps(rows,indent=2)+'\n')
md=['# Production legacy process catalogue','',f'Pinned commit: {SHA}. Direct civ13.dme includes only; lexical setup assignments, not a runtime census. Intervals retain DM expressions. The parent inventory covers processes declared outside code/processes (for example Help). Inherited defaults are in _process.dm.','', '| Type | Interval | Priority | Game states | Source |','|---|---|---|---|---|']
for r in rows:md.append(f"| `{r['type']}` | `{r['schedule_interval']}` | `{r['priority']}` | `{r['fires_at_gamestates']}` | {link(r['file'],r['line'])}; {link('civ13.dme',r['dme_line'])} |")
(O/'process_catalog.md').write_text('\n'.join(md)+'\n')
# Research definitions are one-line constructor calls at this revision. Balanced argument splitting preserves list arguments.
def args(s):
 out=[]; pos=0; depth=0; quoted=False; esc=False
 for i,c in enumerate(s):
  if esc:esc=False;continue
  if c=='\\':esc=True;continue
  if c=='"':quoted=not quoted
  if quoted:continue
  if c=='(':depth+=1
  if c==')':depth-=1
  if c==',' and depth==0:out.append(s[pos:i].strip());pos=i+1
 out.append(s[pos:].strip());return out
nodes=[]
for n,l in enumerate((S/'code/modules/research_tree/research_node.dm').read_text().splitlines(),1):
 m=re.search(r'register_research_node\(new /datum/research_node\((.*)\)\)',l)
 if m:
  a=args(m[1]);nodes.append({'id':a[0].strip('"'),'name':a[1].strip('"'),'category':a[2].strip('"'),'cost_ticks':a[3],'tier':a[4],'mode':a[5],'prerequisites':re.findall(r'"([^"]+)"',a[6]) if len(a)>6 else [],'source_line':n})
(O/'research_nodes.json').write_text(json.dumps(nodes,indent=2)+'\n')
g=['flowchart LR','%% Declared prerequisite graph, not state transitions or proof all nodes are reachable.','%% Source: code/modules/research_tree/research_node.dm at '+SHA]
ids={x['id'] for x in nodes}
for x in nodes:
 label=x['name'].replace('"',"'")
 g += [f'  {x["id"]}["{label}<br/>{x["mode"].replace("RESEARCH_MODE_", "")} / {x["cost_ticks"]} study ticks"]', f'  click {x["id"]} "{BASE}code/modules/research_tree/research_node.dm#L{x["source_line"]}" "Source definition"']
 for p in x['prerequisites']:g.append(f'  {p} --> {x["id"]}')
(O/'08_research_prerequisites.mmd').write_text('\n'.join(g)+'\n')
(O/'research_graph_checks.json').write_text(json.dumps({'nodes':len(nodes),'edges':sum(len(n['prerequisites']) for n in nodes),'unresolved_prerequisites':sorted({p for n in nodes for p in n['prerequisites'] if p not in ids}),'duplicate_ids':sorted({n['id'] for n in nodes if sum(m['id']==n['id'] for m in nodes)>1})},indent=2)+'\n')
print('process setup declarations',len(rows),'research nodes',len(nodes))

# A scalable Graphviz rendering source for the full declared prerequisite graph.
dot=['digraph Research {','  rankdir=LR;','  graph [bgcolor="white",fontname="DejaVu Sans",label="Civ13 declared research prerequisite graph (93 definitions at pinned revision)",labelloc=t];','  node [shape=box,style="rounded,filled",fillcolor="#EDF4FA",fontname="DejaVu Sans",fontsize=10];','  edge [color="#52677A"];']
for x in nodes:
 label=x['name']+'\\n'+x['mode'].replace('RESEARCH_MODE_','')+' / '+x['cost_ticks']+' study ticks'
 dot.append('  '+json.dumps(x['id'])+' [label='+json.dumps(label).replace('\\\\n','\\n')+',URL='+json.dumps(BASE+'code/modules/research_tree/research_node.dm#L'+str(x['source_line']))+'];')
 for p in x['prerequisites']:dot.append('  '+json.dumps(p)+' -> '+json.dumps(x['id'])+';')
dot.append('}')
(O/'08_research_prerequisites.dot').write_text('\n'.join(dot)+'\n')
