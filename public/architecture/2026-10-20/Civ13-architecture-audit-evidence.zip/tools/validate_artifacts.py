import re,sys,json,xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import unquote
root=Path(sys.argv[1]);out=Path(sys.argv[2]);errors=[];links=0;svgs=0
for f in out.rglob('*.md'):
 for p,n,end in re.findall(r'https://github.com/Civ13/Civ13/blob/5bf351248de6050876fe5b53f91209a970cc5668/([^\s)#]+)(?:#L(\d+)(?:-L(\d+))?)?',f.read_text()):
  q=root/unquote(p);links+=1
  if not q.exists():errors.append(f'{f.name}: missing source {p}')
  elif n and int(end or n)>len(q.read_text(errors='replace').splitlines()):errors.append(f'{f.name}: line past EOF {p}:{end or n}')
for f in out.rglob('*.svg'):
 try:ET.parse(f);svgs+=1
 except Exception as e:errors.append(f'{f.name}: invalid XML {e}')
 if 'Syntax Error' in f.read_text(errors='replace'):errors.append(f'{f.name}: renderer syntax error')
result=dict(source_links_checked=links,svg_documents_parsed=svgs,errors=errors)
(out/'inventory/artifact-validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));sys.exit(bool(errors))
