import ast,csv,collections,hashlib,json,subprocess,sys
from pathlib import Path
root=Path(sys.argv[1]);out=Path(sys.argv[2]);inv=out/'inventory'
read=lambda n:list(csv.DictReader((inv/(n+'.csv')).open()))
files=read('files');decl=read('declarations');calls=read('call-sites');hazards=read('dynamic-unresolved')
def group(p):
 parts=p.split('/')
 if p.startswith('code/modules/'):return '/'.join(parts[:3])
 if p.startswith('code/game/'):return '/'.join(parts[:3])
 if p.startswith('code/'):return '/'.join(parts[:2]) if len(parts)>2 else 'code/root'
 return parts[0]
g=collections.defaultdict(collections.Counter)
for f in files:
 if f['in_include_union']=='True':g[group(f['path'])].update(files=1,lines=int(f['lines']))
for name,rows,field in [('decl',decl,'file'),('calls',calls,'file'),('unresolved_sites',hazards,'file')]:
 for r in rows:
  if r['in_include_union']=='True':g[group(r[field])][r.get('kind','calls') if name=='decl' else name]+=1
with (inv/'subsystem-coverage.csv').open('w') as h:
 w=csv.writer(h);w.writerow(['subsystem','included_files','lines','type_declaration_candidates','proc_candidates','call_sites','unresolved_markers'])
 for k,v in sorted(g.items()):w.writerow([k,v['files'],v['lines'],v['type_candidate'],v['proc_candidate'],v['calls'],v['unresolved_sites']])
tracked=subprocess.check_output(['git','-C',str(root),'ls-files'],text=True).splitlines();rev=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip();other=[];symbols=[];imports=[];errors=[]
for f in tracked:
 p=root/f
 if p.suffix not in {'.py','.js','.html','.css','.sh','.ps1','.yml','.yaml','.dmf','.dmm'}:continue
 b=p.read_bytes();other.append([f,len(b),hashlib.sha256(b).hexdigest(),p.suffix])
 if p.suffix=='.py':
  try:tree=ast.parse(b,filename=f)
  except (SyntaxError,UnicodeDecodeError) as e:errors.append({'file':f,'error':str(e)});continue
  for n in ast.walk(tree):
   if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):symbols.append([f,n.lineno,type(n).__name__,n.name,f'https://github.com/Civ13/Civ13/blob/{rev}/{f}#L{n.lineno}'])
   if isinstance(n,ast.Import):imports.extend([f,n.lineno,x.name] for x in n.names)
   if isinstance(n,ast.ImportFrom):imports.append([f,n.lineno,'.'*n.level+(n.module or '')])
for n,rows,fields in [('support-files',other,['path','bytes','sha256','extension']),('python-symbols',symbols,['file','line','kind','name','url']),('python-imports',imports,['file','line','module'])]:
 with (inv/(n+'.csv')).open('w') as h:w=csv.writer(h);w.writerow(fields);w.writerows(rows)
(inv/'python-parse-errors.json').write_text(json.dumps(errors,indent=2)+'\n')
print('Subsystem groups',len(g),'support files',len(other),'Python symbols',len(symbols),'Python parse errors',len(errors))
