from pathlib import Path
import sys,re,json
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
root=Path(sys.argv[1]); files=sorted(root.glob('diagrams/*.png'))+sorted(root.glob('runtime/*.png'))+sorted(root.glob('persistence-services/*.png'))
out=root/'Civ13-architecture-UML-atlas.pdf';c=canvas.Canvas(str(out),pagesize=(842,595));c.setTitle('Civ13 architecture UML atlas');c.setAuthor('Civ13 source architecture audit')
c.setFont('Helvetica-Bold',26);c.drawString(42,535,'Civ13 architecture UML atlas')
c.setFont('Helvetica',12)
lines=['Source snapshot: 5bf351248de6050876fe5b53f91209a970cc5668','Audit date: 2026-10-20','',f'{len(files)} rendered UML diagrams; source-linked reports and machine-readable inventory in companion bundle.','1,462 tracked DM files; 1,257 in literal include closure; 383,278 included source lines.','','Scope: source-level architecture, not deployed-server or runtime acceptance.','Diagram branches are abstractions. Dynamic dispatch, callbacks, external input, loops and','recursion prevent literal enumeration of all possible runtime traces.','', 'Read README.md for findings and evidence limits. Read DIAGRAMS.md for source/render links.','Call-candidate and research-dependency graphs are separate zoomable SVGs.','', 'PDF pages use diagram-specific sizes to preserve labels. Zoom rather than printing to A4.']
y=498
for line in lines:c.drawString(42,y,line);y-=22
c.linkURL('https://github.com/Civ13/Civ13/tree/5bf351248de6050876fe5b53f91209a970cc5668',(42,480,760,510),relative=0)
c.showPage()
for f in files:
 im=Image.open(f);w,h=im.size;scale=.85;pw=max(600,w*scale+64);ph=h*scale+95;c.setPageSize((pw,ph));c.setFont('Helvetica-Bold',12);c.drawString(32,ph-25,f.relative_to(root).as_posix().replace('.png',''));c.setFont('Helvetica',9);c.drawString(32,ph-42,'Pin: 5bf351248de6050876fe5b53f91209a970cc5668 | Selected static architecture paths, not exhaustive runtime paths.')
 c.drawImage(ImageReader(im),32,30,width=w*scale,height=h*scale);c.showPage()
c.save();print(out.name,len(files)+1,'pages')
# Index all semantic diagram sources, prefer PlantUML when both exist.
stems=sorted({p.with_suffix('') for ext in ('*.puml','*.mmd','*.dot') for p in root.rglob(ext)})
lines=['# Diagram index','','PlantUML diagrams are formal component/class/sequence/state views. Mermaid alternatives are retained where available. Graphviz views are labeled dependency or lexical candidate graphs, not UML.','']
for p in stems:
 if 'tools' in p.parts:continue
 rel=p.relative_to(root);links=[]
 for ext in ('.svg','.png','.puml','.mmd','.dot'):
  q=p.with_suffix(ext)
  if q.exists():links.append(f'[{ext[1:].upper()}]({q.relative_to(root).as_posix()})')
 lines.append(f'- **{rel.as_posix()}**: '+ ' | '.join(links))
lines+=['','[PDF atlas](Civ13-architecture-UML-atlas.pdf) | [Audit overview](README.md) | [Runtime/gameplay report](runtime/report.md) | [Persistence/services report](persistence-services/report.md)']
(root/'DIAGRAMS.md').write_text('\n'.join(lines)+'\n')
