#!/usr/bin/env python3
"""Render a bounded name-candidate call neighborhood (not proven dispatch).
python tools/query_graph.py inventory ClickOn output.dot [maximum_targets=80]
Then: dot -Tsvg output.dot -o output.svg
"""
import csv,json,sys
from pathlib import Path
I=Path(sys.argv[1]);name=sys.argv[2];out=Path(sys.argv[3]);limit=int(sys.argv[4]) if len(sys.argv)>4 else 80
D=list(csv.DictReader((I/'declarations.csv').open())); selected=[d for d in D if d['kind']=='proc_candidate' and d['name']==name and d['in_include_union']=='True'];ids={d['id'] for d in selected}
idx=json.loads((I/'call-target-name-index.json').read_text());byid={d['id']:d for d in D};nodes={};edges=[];omitted=0
for d in selected:nodes[d['id']]=d
for c in csv.DictReader((I/'call-sites.csv').open()):
 if c['source_proc'] not in ids:continue
 targets=idx.get(c['name'],[]) or ['UNRESOLVED:'+c['name']]
 for t in targets:
  if t not in nodes and len(nodes)>=limit:omitted+=1;continue
  nodes[t]=byid.get(t,dict(path=t,url=''))
  edges.append((c['source_proc'],t,c['name']+' (name candidate)'))
q=lambda x:json.dumps(x)
lines=['digraph G {','rankdir=LR;','graph [label='+q(f'{name}: lexical name candidates only; {omitted} edges omitted by size limit')+', labelloc=t];','node [shape=box,fontname="DejaVu Sans"];']
for n,d in nodes.items():lines.append(q(n)+' [label='+q(d['path']+'\n'+n)+',URL='+q(d['url'])+'];')
for a,b,l in edges:lines.append(q(a)+' -> '+q(b)+' [style=dashed,label='+q(l)+'];')
lines.append('}');out.write_text('\n'.join(lines)+'\n');print(f'{len(nodes)} nodes, {len(edges)} candidate edges, {omitted} omitted')
