import csv,json,sys
from pathlib import Path
p=Path(sys.argv[1]);d=list(csv.DictReader((p/'declarations.csv').open()));c=list(csv.DictReader((p/'call-sites.csv').open()));f=list(csv.DictReader((p/'files.csv').open()));inc=list(csv.DictReader((p/'includes.csv').open()))
assert len(f)==len({x['path'] for x in f})
assert all(x['exists']=='True' for x in inc)
for path,name in [('code/world.dm','New'),('code/modules/lighting/lighting_system.dm','create_lighting'),('code/_onclick/click.dm','ClickOn'),('code/processes/mob.dm','fire')]:
 assert any(x['file']==path and x['name']==name and x['kind']=='proc_candidate' for x in d),(path,name)
for path,name in [('code/processes/mob.dm','Life'),('code/world.dm','callHook'),('code/modules/lighting/lighting_system.dm','create_all_lighting_corners')]:
 assert any(x['file']==path and x['name']==name for x in c),(path,name)
assert next(x for x in f if x['path']=='code/modules/gameplay_bridge/bridge.dm')['in_include_union']=='False'
assert next(x for x in f if x['path']=='code/modules/persistence/immutable_capture.dm')['in_include_union']=='False'
print('PASS: unique file inventory, literal includes exist, 4 declaration anchors, 3 call anchors, 2 excluded feature anchors. This validates accounting/spot checks only, not parser completeness or runtime behavior.')
