#!/usr/bin/env python3
"""Conservative lexical DM inventory. Not a compiler, preprocessor or sound call graph.
Run: python tools/build_inventory.py SOURCE_ROOT OUTPUT_ROOT
No execution of repository code. Outputs relative source paths and immutable links.
"""
import csv, hashlib, json, re, subprocess, sys
from pathlib import Path
from collections import Counter, defaultdict
ROOT=Path(sys.argv[1]); OUT=Path(sys.argv[2]); OUT.mkdir(parents=True,exist_ok=True)
REV=subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip()
BASE=f'https://github.com/Civ13/Civ13/blob/{REV}/'
def link(f,n=1):return BASE+f+'#L'+str(n)
def clean(text):
    # Preserve positions/newlines, mask comments and strings, including interpolation.
    pattern=r'/\*[\s\S]*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|\x27(?:\\.|[^\x27\\])*\x27'
    return re.sub(pattern,lambda m:re.sub(r'[^\n]',' ',m.group()),text)
def write(name,rows,fields):
    with (OUT/(name+'.csv')).open('w',newline='') as h:
        w=csv.DictWriter(h,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
tracked=subprocess.check_output(['git','-C',str(ROOT),'ls-files'],text=True).splitlines()
includes=[]; reached=set(); pending=['civ13.dme']
while pending:
    file=pending.pop()
    if file in reached:continue
    reached.add(file)
    p=ROOT/file
    if not p.exists():continue
    # Include directives in comment-free text, preserve quoted paths separately.
    text=p.read_text(errors='replace'); no_comments=re.sub(r'/\*[\s\S]*?\*/|//[^\n]*',lambda m:'\n'*m.group().count('\n'),text)
    for n,line in enumerate(no_comments.splitlines(),1):
        m=re.match(r'\s*#include\s+"([^"]+)"',line)
        if not m:continue
        target=m[1].replace('\\','/'); resolved=(Path(file).parent/target).as_posix()
        if not (ROOT/resolved).exists() and (ROOT/target).exists():resolved=target
        includes.append(dict(source=file,line=n,target=resolved,exists=(ROOT/resolved).exists(),semantics='textual conditional-union; conditions not evaluated',url=link(file,n)))
        if resolved.endswith(('.dm','.dme')) and (ROOT/resolved).exists():pending.append(resolved)
files=[]; declarations=[]; calls=[]; controls=[]; hazards=[]; preproc=[]; inheritance=[]; statements=[]; edges=[]
keywords={'if','else','for','while','switch','return','catch','spawn','sleep','do','try','set','var'}
proc_rx=re.compile(r'^(/?[A-Za-z_][\w/]*|/[^\s(]+)\s*\(')
type_rx=re.compile(r'^/?[A-Za-z_]\w*(?:/[A-Za-z_]\w*)*/?$')
call_rx=re.compile(r'(?:(?P<recv>[\w.?:]+)[.:])?(?P<name>[A-Za-z_]\w*|\.\.)\s*\(')
for file in sorted(f for f in tracked if f.endswith('.dm')):
    p=ROOT/file; raw=p.read_text(errors='replace'); lines=raw.splitlines(); masked=clean(raw).splitlines(); included=file in reached
    files.append(dict(path=file,lines=len(lines),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),in_include_union=included,url=link(file)))
    stack=[]; active=None; proc_indent=-1; prev=None; pending_branch=[]
    for n,s in enumerate(masked,1):
        orig=lines[n-1]; st=s.strip(); indent=len(s.expandtabs(4))-len(s.expandtabs(4).lstrip())
        if not st:continue
        if st.startswith('#'):
            preproc.append(dict(file=file,line=n,directive=orig.strip(),in_include_union=included,url=link(file,n)));continue
        if active and indent<=proc_indent:
            active=None;prev=None
        while stack and indent<=stack[-1][0]:stack.pop()
        ctx=stack[-1][1] if stack else ''
        m=proc_rx.match(st)
        declaration=False
        if not active and m and (st.startswith('/') or (m[1] not in keywords and not re.search(r'[=.]',m[1]) and (indent==0 or ctx))):
            name=m[1]
            # exclude macro invocations, variable initializers, inline expressions.
            if not (name.isupper() or name.startswith(('var/','/var/'))):
                full=name if name.startswith('/') else (ctx+'/'+name if ctx else '/'+name)
                full=full.replace('/proc/','/').replace('/verb/','/')
                ident=f'{file}:{n}'; active=ident;proc_indent=indent;prev=None
                declarations.append(dict(id=ident,kind='proc_candidate',path=full,name=full.rsplit('/',1)[-1],file=file,line=n,in_include_union=included,url=link(file,n),confidence='lexical, not compiler-resolved'))
                declaration=True
        if not active and type_rx.fullmatch(st) and not st.startswith(('var','/var','return','break','continue')):
            full=st.rstrip('/') if st.startswith('/') else ctx+'/'+st.rstrip('/')
            if full.split('/')[-1] not in ('proc','verb','var'):
                declarations.append(dict(id=f'{file}:{n}',kind='type_candidate',path=full,name=full.rsplit('/',1)[-1],file=file,line=n,in_include_union=included,url=link(file,n),confidence='lexical declaration/reopening'))
                inheritance.append(dict(child=full,parent=full.rsplit('/',1)[0] or '(native root)',kind='path-default candidate; parent_type may override',file=file,line=n,url=link(file,n),in_include_union=included))
            stack.append((indent,full))
        if re.match(r'parent_type\s*=',st):
            parent=st.split('=',1)[1].strip();inheritance.append(dict(child=ctx,parent=parent,kind='explicit parent_type',file=file,line=n,url=link(file,n),in_include_union=included))
        if active and not declaration:
            sid=f'{file}:{n}'; kind=(re.match(r'\w+',st)[0] if re.match(r'\w+',st) else 'expression')
            statements.append(dict(id=sid,proc=active,file=file,line=n,indent=indent,kind=kind,in_include_union=included,url=link(file,n)))
            if prev:edges.append(dict(source=prev,target=sid,kind='lexical-next only; NOT executable CFG',proc=active))
            prev=sid
            if kind in keywords:controls.append(dict(proc=active,file=file,line=n,kind=kind,indent=indent,in_include_union=included,url=link(file,n)))
        if not declaration:
            for cm in call_rx.finditer(s):
                name=cm['name'];receiver=cm['recv'] or ''
                if name in keywords:continue
                calls.append(dict(id=f'{file}:{n}:{cm.start()+1}',source_proc=active or '(declaration/global/unparsed)',name=name,receiver=receiver,file=file,line=n,column=cm.start()+1,in_include_union=included,resolution='parent dispatch unresolved' if name=='..' else 'receiver/dynamic dispatch unresolved' if receiver else 'name-only candidate; builtin/macro/global/inherited ambiguous',url=link(file,n)))
        for pattern,label in [(r'\b(spawn|sleep)\b','async/yield'),(r'\b(call|callHook|Invoke|InvokeAsync|CALLBACK|addtimer|_addtimer|typesof|subtypesof|text2path|locate|new)\b','dynamic/construction/callback'),(r'\bvars\s*\[','reflective variable access'),(r'\b[A-Z][A-Z_]+\s*\(','macro invocation')]:
            for hm in re.finditer(pattern,s):hazards.append(dict(file=file,line=n,proc=active or '',kind=label,token=hm.group(),in_include_union=included,url=link(file,n)))
        # Strings hide executable interpolation and string-literal proc targets.
        if '[' in orig and '"' in orig:hazards.append(dict(file=file,line=n,proc=active or '',kind='string interpolation opaque to scanner',token='quoted interpolation candidate',in_include_union=included,url=link(file,n)))
write('files',files,['path','lines','bytes','sha256','in_include_union','url'])
for name,rows,fields in [
 ('includes',includes,['source','line','target','exists','semantics','url']),
 ('declarations',declarations,['id','kind','path','name','file','line','in_include_union','confidence','url']),
 ('inheritance',inheritance,['child','parent','kind','file','line','in_include_union','url']),
 ('call-sites',calls,['id','source_proc','name','receiver','file','line','column','in_include_union','resolution','url']),
 ('control-sites',controls,['proc','file','line','kind','indent','in_include_union','url']),
 ('dynamic-unresolved',hazards,['file','line','proc','kind','token','in_include_union','url']),
 ('preprocessor',preproc,['file','line','directive','in_include_union','url']),
 ('statements',statements,['id','proc','file','line','indent','kind','in_include_union','url']),
 ('lexical-order-edges',edges,['source','target','kind','proc'])]:write(name,rows,fields)
index=defaultdict(list)
for d in declarations:
    if d['kind']=='proc_candidate':index[d['name']].append(d['id'])
(OUT/'call-target-name-index.json').write_text(json.dumps(index,indent=2))
counts={k:len(v) for k,v in dict(files=files,includes=includes,declarations=declarations,calls=calls,controls=controls,dynamic_sites=hazards,statements=statements,lexical_edges=edges).items()}
counts.update(included_dm_files=sum(f['in_include_union'] for f in files),included_dm_lines=sum(f['lines'] for f in files if f['in_include_union']),all_dm_lines=sum(f['lines'] for f in files),included_proc_candidates=sum(d['kind']=='proc_candidate' and d['in_include_union'] for d in declarations),included_type_declarations=sum(d['kind']=='type_candidate' and d['in_include_union'] for d in declarations))
meta=dict(revision=REV,entry='civ13.dme',counts=counts,scope='Every tracked .dm file inventoried; include union is transitive literal include reachability, NOT evaluated compilation.',limits=['Not a DM parser/compiler; nested indentation recognized heuristically.','Comments/strings masked; string interpolation remains unresolved, marked explicitly.','No preprocessing or macro expansion; conditional union can include inactive branches.','Name-index joins are possible targets, not proved runtime calls.','Lexical-order edges are source navigation only, not executable control flow.','Implicit engine callbacks, dynamic types, reflection, timers, exceptions and external messages are not enumerated runtime paths.'])
(OUT/'coverage.json').write_text(json.dumps(meta,indent=2)+'\n'); print(json.dumps(meta,indent=2))
